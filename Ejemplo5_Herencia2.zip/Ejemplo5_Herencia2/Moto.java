package Ejemplo5_Herencia2;

public class Moto extends Vehiculo {
    private int calif_nivel_vibracion;

    public Moto(String placa, String marca, String modelo, int año_fabricacion, String tipo_motor, int calif_sistema_direccion, int calif_sistema_frenos, int calif_emision_gases, int calif_emisiones_sonoras, int calif_nivel_vibracion) {
        super(placa, marca, modelo, año_fabricacion, tipo_motor, calif_sistema_direccion, calif_sistema_frenos, calif_emision_gases, calif_emisiones_sonoras);
        this.calif_nivel_vibracion = calif_nivel_vibracion;
        this.setTarifa_revision(25);
    }

    @Override
    public int obtener_calificacion_general() {
        return super.obtener_calificacion_general() + this.calif_nivel_vibracion;
    }

    @Override
    public String toString() {
        return "Moto { " +
                super.toString() +
                ", calif_nivel_vibracion=" + calif_nivel_vibracion +
                ", Calificación Final = " + this.obtener_calificacion_general() +
                " } ";
    }
}
