package Ejemplo5_Herencia2;

public class Pesado extends Vehiculo {
    private int calif_sistema_suspension;

    public Pesado(String placa, String marca, String modelo, int año_fabricacion, String tipo_motor, int calif_sistema_direccion, int calif_sistema_frenos, int calif_emision_gases, int calif_emisiones_sonoras, int calif_sistema_suspension) {
        super(placa, marca, modelo, año_fabricacion, tipo_motor, calif_sistema_direccion, calif_sistema_frenos, calif_emision_gases, calif_emisiones_sonoras);
        this.calif_sistema_suspension = calif_sistema_suspension;
        this.setTarifa_revision(120);
    }

    @Override
    public int obtener_calificacion_general() {
        return super.obtener_calificacion_general() + this.calif_sistema_suspension;
    }

    @Override
    public String toString() {
        return "Pesado { " +
                super.toString() +
                ", calif_sistema_suspension=" + calif_sistema_suspension +
                ", Calificación Final = " + this.obtener_calificacion_general() +
                '}';
    }
}
