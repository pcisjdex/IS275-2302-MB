package Ejemplo5_Herencia2;

public class Ejecutora {
    public static void main(String[] args) {
        Empresa_Revisiones empresa = new Empresa_Revisiones("FARENET");

        empresa.agregarVehiculo(new Moto("ABC-123", "Honda", "M1", 2015, "T1", 1, 2, 3, 4, 4));
        empresa.agregarVehiculo(new Moto("ABC-456", "Kawasaki", "M2", 2020, "T2", 3, 2, 3, 4, 4));

        empresa.agregarVehiculo(new Ligero("DEF-159", "Mercedes", "M3", 2014, "T3", 2, 1, 4, 3, 1));
        empresa.agregarVehiculo(new Ligero("DEF-468", "BMW", "M4", 2022, "T4", 3, 2, 4, 1, 4));

        empresa.agregarVehiculo(new Pesado("GHI-987", "Caterpillar", "C1", 2005, "T5", 1, 2, 3, 4, 0));
        empresa.agregarVehiculo(new Pesado("GHI-654", "Cat", "C2", 2015, "T6", 2, 2, 3, 4, 2));

        empresa.listarVehiculos();
    }
}
