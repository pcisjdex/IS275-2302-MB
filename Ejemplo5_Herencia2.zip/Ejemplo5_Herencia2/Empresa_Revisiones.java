package Ejemplo5_Herencia2;

import java.util.ArrayList;
import java.util.List;

public class Empresa_Revisiones {
    private String nombre;
    private List<Vehiculo> listaVehiculos;

    public Empresa_Revisiones(String nombre) {
        this.nombre = nombre;
        this.listaVehiculos = new ArrayList<>();
    }

    public void agregarVehiculo(Vehiculo v) {
        listaVehiculos.add(v);
    }

    public void listarVehiculos() {
        for (Vehiculo v : listaVehiculos) {
            System.out.println(v);
        }
    }
}
