package Ejemplo6_ConcursoCanes;

public class Trabajo extends Perro {
    private String raza;
    private int habilidad;

    public Trabajo(String nombre, int postura, String raza, int habilidad) {
        super(nombre, postura);
        this.raza = raza;
        this.habilidad = habilidad;
    }

    @Override
    public int calificacion() {
        return super.calificacion() + this.habilidad;
    }

    @Override
    public String toString() {
        return "Trabajo{ " +
                super.toString() +
                ", raza='" + raza + '\'' +
                ", habilidad=" + habilidad +
                ", calificación final= " + this.calificacion() +
                " }";
    }
}
