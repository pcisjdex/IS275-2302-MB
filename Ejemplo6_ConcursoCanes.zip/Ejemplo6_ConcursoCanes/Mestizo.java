package Ejemplo6_ConcursoCanes;

public class Mestizo extends Perro {
    private int aceptacion_publico;
    private int disciplina;

    public Mestizo(String nombre, int postura, int aceptacion_publico, int disciplina) {
        super(nombre, postura);
        this.aceptacion_publico = aceptacion_publico;
        this.disciplina = disciplina;
    }

    @Override
    public int calificacion() {
        return super.calificacion() + (this.aceptacion_publico + this.disciplina) / 2;
    }

    @Override
    public String toString() {
        return "Mestizo { " +
                super.toString() +
                ", aceptacion_publico=" + aceptacion_publico +
                ", disciplina=" + disciplina +
                ", calificación final= " + this.calificacion() +
                " }";
    }
}
