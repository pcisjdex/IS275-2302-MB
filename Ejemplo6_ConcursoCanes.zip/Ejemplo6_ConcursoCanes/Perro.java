package Ejemplo6_ConcursoCanes;

public class Perro {
    private String nombre;
    private int postura;

    public Perro(String nombre, int postura) {
        this.nombre = nombre;
        this.postura = postura;
    }

    public String getNombre() {
        return nombre;
    }

    public int calificacion() {
        return this.postura * 9;
    }

    @Override
    public String toString() {
        return "nombre='" + nombre + '\'' +
               ", postura=" + postura;
    }
}
