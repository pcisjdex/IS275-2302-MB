package Ejemplo6_ConcursoCanes;

public class Ejecutora {
    public static void main(String[] args) {
        ConcursoCanino concurso = new ConcursoCanino();
        concurso.agregarPerro(new Trabajo("Fido", 4, "Raza 1", 5));
        concurso.agregarPerro(new Trabajo("Copita", 3, "Raza 2", 4));
        concurso.agregarPerro(new Compañía("Malo", 6, "Raza 3", 1));
        concurso.agregarPerro(new Compañía("Huesos", 7, "Raza 4", 2));
        concurso.agregarPerro(new Mestizo("Run Run", 8, 1, 2));
        concurso.agregarPerro(new Mestizo("Lobito", 5, 2, 4));

        concurso.imprimirListaPerros();

        System.out.println(concurso.obtenerGanadorGeneral());

        concurso.imprimirGanadoresXCategoria();
    }
}
