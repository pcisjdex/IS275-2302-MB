package Ejemplo6_ConcursoCanes;

public class Compañía extends Perro {
    private String raza;
    private int pelaje;

    public Compañía(String nombre, int postura, String raza, int pelaje) {
        super(nombre, postura);
        this.raza = raza;
        this.pelaje = pelaje;
    }

    @Override
    public int calificacion() {
        return super.calificacion() + this.pelaje;
    }

    @Override
    public String toString() {
        return "Compañía { " +
                super.toString() +
                ", raza='" + raza + '\'' +
                ", pelaje=" + pelaje +
                ", calificación final= " + this.calificacion() +
                " }";
    }
}
