package Ejemplo6_ConcursoCanes;

import java.util.ArrayList;
import java.util.List;

public class ConcursoCanino {
    private List<Perro> listaPerros;

    public ConcursoCanino() {
        this.listaPerros = new ArrayList<>();
    }

    public void agregarPerro(Perro perro) {
        listaPerros.add(perro);
    }

    public void imprimirListaPerros() {
        for (Perro perro : listaPerros) {
            System.out.println(perro);
        }
    }

    public String obtenerGanadorGeneral() {
        int puntajeMayor = 0;
        int calificacionPerro;
        String nombrePerroGanador = "";

        for (Perro perro : listaPerros) {
            calificacionPerro = perro.calificacion();
            if (calificacionPerro > puntajeMayor) {
                puntajeMayor = calificacionPerro;
                nombrePerroGanador = perro.getNombre();
            }
        }
        return "El perro ganador es " + nombrePerroGanador + " y su calificación es de " + puntajeMayor;
    }

    public void imprimirGanadoresXCategoria() {
        int puntajeMayorTrabajo = 0;
        String nombrePerroGanadorTrabajo = "";
        int puntajeMayorCompañia = 0;
        String nombrePerroGanadorCompañia = "";
        int puntajeMayorMestizo = 0;
        String nombrePerroGanadorMestizo = "";
        int calificacionPerro;

        for (Perro perro : listaPerros) {
            calificacionPerro = perro.calificacion();
            if (perro instanceof Trabajo && calificacionPerro > puntajeMayorTrabajo) {
                puntajeMayorTrabajo = calificacionPerro;
                nombrePerroGanadorTrabajo = perro.getNombre();
            } else if (perro instanceof Compañía && calificacionPerro > puntajeMayorCompañia) {
                puntajeMayorCompañia = calificacionPerro;
                nombrePerroGanadorCompañia = perro.getNombre();
            } else if (perro instanceof Mestizo && calificacionPerro > puntajeMayorMestizo) {
                puntajeMayorMestizo = calificacionPerro;
                nombrePerroGanadorMestizo = perro.getNombre();
            }
        }
        System.out.println("El perro ganador de la categoría Trabajo es " + nombrePerroGanadorTrabajo + " y su calificación es de " + puntajeMayorTrabajo);
        System.out.println("El perro ganador de la categoría Compañía es " + nombrePerroGanadorCompañia + " y su calificación es de " + puntajeMayorCompañia);
        System.out.println("El perro ganador de la categoría Mestizo es " + nombrePerroGanadorMestizo + " y su calificación es de " + puntajeMayorMestizo);
    }
}
